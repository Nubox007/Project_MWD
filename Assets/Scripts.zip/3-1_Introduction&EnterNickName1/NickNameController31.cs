using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NickNameController31 : MonoBehaviour
{

    public void NickNameBtn()
    {
        SceneManager.LoadScene("3-2_Input_NickName"); 
    }
}
