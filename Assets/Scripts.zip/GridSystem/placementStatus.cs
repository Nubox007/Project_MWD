 public enum placementStatus 
{
    Empty, Filled, Unable
}   
